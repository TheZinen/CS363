<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>
			Movie Tickets
		</title>
	</head>
	<body>
        <?php

        // Movies class that holds our functions
        class Movies
        {
            // Private variable / function to store it
            private $custage=0;
            public function age($custage)
            {
                $this->custage=$custage;
            }

            // Function to calculate our prices
            public function calprice($movieticketPrice)
            {
                // Age is less than 5 years old
                if($this->custage < 5)
                {
                    return 0;  
                }

                // Age is between 18 and 5 years old
                else if ($this->custage > 5 && $this->custage < 18)
                {
                    return $movieticketPrice / 2;
                }

                // Age is between 55 and 19 years old
                else if($this->custage >= 18 && $this->custage <= 55)
                {
                    return $movieticketPrice;
                } 

                // Age is greater than 55 years old
                else
                {
                    return $movieticketPrice - (float) ("2.00");
                }
            }

        }

        // Puts and pull variables into different functions/variables
        $movieObj = new Movies();
        $fullPriceTicket = 10;
        $movieObj -> age(4);

        // Pulls the numbers from our function
        $ticketPrice=$movieObj -> calprice($fullPriceTicket);

        // Display the prices
        echo"<p> If the age is 4, the ticket price is $ticketPrice </p>\n";

        $movieObj -> age(16);
        $ticketPrice=$movieObj -> calprice($fullPriceTicket);
        echo"<p> If the age is 16, the ticket price is $ticketPrice </p>\n";

        $movieObj -> age(45);
        $ticketPrice=$movieObj -> calprice($fullPriceTicket);
        echo"<p> If the age is 45, the ticket price is $ticketPrice </p>\n";

        $movieObj -> age(57);
        $ticketPrice=$movieObj -> calprice($fullPriceTicket);
        echo"<p> If the age is 57, the ticket price is $ticketPrice </p>\n";
    ?>
	</body>
</html>