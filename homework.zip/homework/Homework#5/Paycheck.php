<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>
            Paycheck Calculator
        </title>
    </head>
    <body>
    <h1> Paycheck Calculator </h1><hr /> 
        <?php
            $hours = $_GET["hours"];
            $wages = $_GET["wage"];
            $pay = 0;

        if ((is_numeric($hours)) & (is_numeric($wages)))
        {
            if ( $hours > 0 & $wages > 0)
                {
                    $overtime = max($hours - 40, 0);
                    $pay += $overtime * $wages * 1.5;
                    $pay += ($hours - $overtime) * $wages;

                    echo "Number of Hours (per week): " . $hours . "<br>";
                    echo "Pay rate (per hour): $" . number_format($wages, 2) . "<br>";
                    echo "Overtime Hours: " . $overtime . "<br>";
                    echo "Overall Pay: $" . number_format($pay, 2) . "<br>";
                }

            else
                {
                    echo "incorrect input: wages or hours worked should be greater than zero(0)";
                }
        }

        else
            {
                echo "hours worked or wage rate should be numeric ";
            }
        ?>
    </body>
</html>