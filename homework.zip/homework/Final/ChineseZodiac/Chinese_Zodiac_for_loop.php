<style>
table {
  border: 1px solid black;
  width: 100%;
}
td {
  border: 1px solid black;
}
</style>

<?php


$signs = array( "rat", "ox", "tiger", "rabbit", "dragon", "snake", "horse", "sheep", "monkey", "rooster", "dog", "pig");
date_default_timezone_set('America/Los_Angeles');
$col = 1;

echo '<table>';
echo '<tr>';

for ( $sign = 0; $sign < count($signs); ++$sign) {
  echo '<td><img src="images/'.$signs[$sign].'.png"></td>';
}
echo '</tr>';
echo '<tr>';
for ( $year = 1912; $year <= date("Y"); ++$year ) {
  echo '<td>'.$year.'</td>';
  if ( $col % 12 === 0 ) {
    echo '</tr>';
    echo '<tr>';
  }
  $col++;
}
echo '</tr>';
echo '</table>';
?>
