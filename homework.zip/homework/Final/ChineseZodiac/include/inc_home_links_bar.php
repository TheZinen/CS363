<a href="index.php?page=home_page&section=php">PHP</a>
<a href="index.php?page=home_page&section=zodiac">Chinese Zodiac</a>
