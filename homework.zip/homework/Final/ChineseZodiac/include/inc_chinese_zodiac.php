<p>The Chinese zodiac, or shengxiao (/shnng-sshyao/ ‘born resembling'), 
is a repeating cycle of 12 years, with each year being represented by 
an animal and its reputed attributes. In order, the 12 Chinese horoscope animals are:</p>

<ul>
 <li>Rat</li>
 <li>Ox</li>
 <li>Tiger</li>
 <li>Rabbit</li>
 <li>Dragon</li>
 <li>Snake</li>
 <li>Horse</li>
 <li>Goat</li>
 <li>Monkey</li>
 <li>Rooster</li>
 <li>Dog</li>
 <li>Pig</li>
</ul>

<p>
    It's believed that people born in a given year have the personality of that year's animal.
</p>

