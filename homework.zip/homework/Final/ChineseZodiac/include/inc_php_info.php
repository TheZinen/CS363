
<p>
PHP is an open-source, server-side scripting and 
programming language that’s primarily used for web development. 
PHP (recursive acronym for PHP: Hypertext Preprocessor) is a general-purpose 
scripting language that is especially suited for web development and can be embedded into HTML.
</p>
