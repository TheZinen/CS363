Dynamic web content is website content that is generated during page loading from various sources. The sources can include:

<ul>
  <li>Session Variables</li>
  <li>Database lookups</li>
  <li>Cookies</li>
</ul>

Dynamic content (aka adaptive content) refers to web content that changes based on the behavior, preferences, and interests of the user. It refers to websites as well as e-mail content and is generated at the moment a user requests a page. Dynamic content is personalized and adapts based on the data you have about the user and on the access time, its goal being to deliver an engaging and satisfying online experience for the visitor.