<?php
include('include/inc_home_links_bar.php');
if (isset($_GET['section'])) {
  switch ($_GET['section']) {
    case 'zodiac':
      include('include/inc_chinese_zodiac.php');
      break;
    case 'php':
    default:
      include('include/inc_php_info.php');
      break;
   }
}
else
  include('include/inc_php_info.php');
?>
