<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>
			Game
		</title>
	</head>
	<body>
    <center><form action="game_check.php" method="POST">
    Guess a number 1-100:<input type="text" name="userGuess"/>
    <input type="submit" value="Guess"/>

    </form></center>
    <center><form action="game.php">
    <input type="submit" value="Restart"/>
    </form></center>
    <?php
        session_start();
        
        $_SESSION['randNum'] = isset($_SESSION['randNum']) ? $_SESSION['randNum'] : rand(1, 100);
        $_SESSION['guesses'] = isset($_SESSION['guesses']) ? $_SESSION['guesses'] : 0;
    ?>
	</body>
</html>