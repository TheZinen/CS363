<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<body>
        <?php
  
        // Read answerkey.txt
        function readAnswerKey($filename) 
        {
            // Puts our answerkey.txt file into an array
            $answerKey = array();
            
            // If the answer key exists and is readable, will store in an array
            if (file_exists($filename) && is_readable($filename)) 
            {
                $answerKey = file($filename);
            }
            return $answerKey;
        }

        // Reads the questions file and returns a nested array (for the questions and answers)
        function readQuestions($filename) 
        {
            // Each element of the array is the question followed by the answer
            $displayQuestions = array();
            
            if (file_exists($filename) && is_readable($filename)) 
            {
                $questions = file($filename);
            
                // Loop through each line and explode it into question and choices
                foreach ($questions as $key => $value) 
                {
                    $displayQuestions[] = explode(":",$value);
                }				
            }

            // Will error out if the function is unable to pull questions from txt file
            else { echo "Error finding or reading questions file."; }   
            return $displayQuestions;
        }

        // Function that displays our questions and choices given
        function displayTheQuestions($questions) 
        {
            if (count($questions) > 0) 
            {
                $counter = 0;
                foreach ($questions as $key => $value) 
                {
                    echo "<b>$value[0]</b><br/>";
                    
                    // Splits the choices up into different arrays
                    $choices = explode(",",$value[1]);
                    
                    // Function that creates a radio button for every question applicable
                    foreach($choices as $value) 
                    {
                        if ($counter++ < 18)
                        {
                            $letter = substr(trim($value),0,1);
                            echo "<input type=\"radio\" name=\"$key\" value=\"$letter\" required/>$value<br/>";
                        }
                        else 
                        { 
                            echo "<input type=\"text\" name=\"$key\" required/>"; 
                        }
                    }
                    echo "<br/><br/>";
                }
            }
            else { echo "No questions to display."; }
        }


        // Function that calculates the grade the user receives
        function translateToGrade($percentage) 
        {
            if ($percentage >= 90.0) { return "A"; }
            else if ($percentage >= 80.0) { return "B"; }
            else if ($percentage >= 70.0) { return "C"; }
            else if ($percentage >= 60.0) { return "D"; }
            else { return "F"; }
        }
        ?>

    <h2>CS363 Midterm Quiz!</h2>
    <h4>Please complete the following questions as accurately as possible.</h4>
    
        <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">

        <div>
            <h3>Your Name: <h3><input type="text" name="Name" required/>
            <h3>Your Email: <h3><input type="email" name="Email" required/>
        </div>

        <?php
            echo "<br>";
            // Loads in the questions from our file
            $loadedQuestions = readQuestions("questions.txt");
            
            // Display the questions
            displayTheQuestions($loadedQuestions);
        ?>

        <input type="reset" name="resetquiz" value="Reset Quiz"/>
        <input type="submit" name="submitquiz" value="Submit Quiz"/>
            <?php
            // Button that grades our quiz
            if (isset($_POST['submitquiz'])) 
            {
                // Pulls our answerkey from file as well as hold our userInput from earlier
                $answerKey = readAnswerKey("answerkey.txt");
                $answerCount = count($answerKey);
                $correctCount = 0;
                $wrongCount = 0;
                $username = $_POST['Name'];
                $useremail = $_POST['Email'];

                // Compares the submissions with answer key
                foreach ($answerKey as $key => $keyanswer) 
                {
                    if (isset($_POST[$key])) 
                    {
                        // If user got answer correct, increments by 1
                        if (strtoupper(rtrim($keyanswer)) == strtoupper($_POST[$key])) 
                        {
                            $correctCount++;
                        }
                        else   
                            $wrongCount++;
                    }
                }

                // Outputs our name, email, total questions, and number of correct questions
                echo "<br/><br/>Your Name: $username<br/>";
                echo "Your Email: $useremail<br/>";
                echo "Total Questions: $answerCount<br/>";
                echo "Number Correct: $correctCount<br/>";
                echo "Number Wrong: $wrongCount<br/><br/>";

                if ($answerCount > 0) 
                {
                    // Gives both a percentage and a letter grade
                    $percentage = round((($correctCount / $answerCount) * 100),1);
                    echo "Total Score: $percentage% (Grade: " . translateToGrade($percentage) . ")<br/>";
                }
                else 
                {
                    // If something didn't output properly, defaults to F
                    echo "Total Score: 0 (Grade: F)";
                }
            }

            ?>
        </form>
    </body>
</html>