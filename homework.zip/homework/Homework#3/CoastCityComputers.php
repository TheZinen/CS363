<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>
			Coast City Computer
		</title>
	</head>
	<body>
    <?php include("inc_header.php"); ?>  
    <h2>Memorial Day Sale</h2>
    <ul>
        <li>Compaq Presario m2007us Notebook:
            <strong>$799.99</strong></li>
        <li>Epson Stylus CX6600 Color All-In-One Printer,
        Print/Copy/Scan: <strong>$699.99</strong></li>
        <li>Proview Technology Inc. KDS K715s 17-inch LCD
        Monitor,
        Silver/Black: <strong>$199.99</strong></li>
        <li>Hawking Technology Hi-Speed Wireless-G Cardbus
        Card:
        <strong>$9.99</strong></li>
    </ul>
    <?php include("inc_footer.php"); ?>
	</body>
</html>