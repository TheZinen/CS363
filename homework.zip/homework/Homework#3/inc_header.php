<table width="100%" style="border: 0">
<tr><td><h1>Coast City Computers</h1></td>
<td style="text-align: right"><strong>Buy Online or
Call 1-800-555-1212</strong></td></tr></table><hr />